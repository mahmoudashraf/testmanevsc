package tutorial1;

public class Demo {

	public boolean getBool() {
		return true;
	}
}
