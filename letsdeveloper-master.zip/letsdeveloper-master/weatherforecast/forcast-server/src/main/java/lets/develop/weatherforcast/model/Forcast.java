package lets.develop.weatherforcast.model;

public class Forcast {

}
