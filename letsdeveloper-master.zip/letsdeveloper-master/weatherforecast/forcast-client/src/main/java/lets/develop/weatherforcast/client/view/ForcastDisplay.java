package lets.develop.weatherforcast.client.view;

import lets.develop.weatherforcast.model.Forcast;

public class ForcastDisplay {

	public Forcast currentForcast;
}
